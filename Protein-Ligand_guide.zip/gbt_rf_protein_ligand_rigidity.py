import numpy as np
import scipy as sp
from sklearn import ensemble
from sklearn.metrics import mean_squared_error
from math import sqrt

def gbt_rf():
    X_train = np.load("train_RIScore_E.npy")
    X_test = np.load("test_RIScore_E.npy")
    Y_test = np.load("test_BindingAffinity.npy")
    Y_train = np.load("train_BindingAffinity.npy")

    for i in range(5):
    # GBT
        params={'n_estimators': 20000, 'max_depth': 8, 'min_samples_split': 2,
                'learning_rate': 0.001, 'loss': 'ls','max_features':'sqrt','subsample':0.7}
        clf = ensemble.GradientBoostingRegressor(**params)
        clf.fit(X_train, Y_train)
        mse = mean_squared_error(Y_test, clf.predict(X_test))
        print("RMSE: %.4f" % sqrt(mse))
        pearcorr = sp.stats.pearsonr(Y_test, clf.predict(X_test))
        print(pearcorr)
    # Random forest
        regr = ensemble.RandomForestRegressor(n_estimators = 1000,max_features='auto')
        regr.fit(X_train,Y_train)
        mse = mean_squared_error(Y_test, regr.predict(X_test))
        print("RMSE: %.4f" % sqrt(mse))
        pearcorr = sp.stats.pearsonr(Y_test, regr.predict(X_test))
        print(pearcorr)