import numpy as np
import scipy as sp
from sklearn import ensemble
from sklearn.metrics import mean_squared_error
import math

eleid = {'C':1, 'N':2, 'O':3, 'S':4, 'P':5, 'F':6, 'CL':7, 'BR':8, 'I':9}
vdw = {'C':1.20, 'N':1.55, 'O':1.52, 'S':1.80, 'P':1.80, 'F':1.47, 'CL':1.75, 'BR':1.85, 'I':1.98}
aa_list = ['ALA','ARG','ASN','ASP','CYS','GLU','GLN','GLY','HIS','HSE','HSD','SEC',
           'ILE','LEU','LYS','MET','PHE','PRO','SER','THR','TRP','TYR','VAL','PYL']

def listprep(name1, name2):
    f = open(name1, 'r')
    g = open(name2, 'r')
    contents = f.readlines()
    contents1 = g.readlines()

    refined_set = []
    for i in range(6,len(contents)):
        refined_set = np.append(refined_set, contents[i][:4])
    
    core_set = []
    for i in range(6,len(contents1)):
        core_set = np.append(core_set, contents1[i][:4])

    training_set = list(set(refined_set).symmetric_difference(core_set))
    test_set = core_set

    train_BindingAffinity = []
    test_BindingAffinity = []
    for i in range(len(training_set)):
        for j in range(6, len(contents)):
            if contents[j][:4]==training_set[i]:
                #print(training_set[i], contents[j][19:23])
                train_BindingAffinity = np.append(train_BindingAffinity, float(contents[j][18:23]))
                
    for i in range(len(test_set)):
        for j in range(6, len(contents)):
            if contents[j][:4]==test_set[i]:
                #print(training_set[i], contents[j][19:23])
                test_BindingAffinity = np.append(test_BindingAffinity, float(contents[j][18:23]))

    np.save("train_BindingAffinity.npy", train_BindingAffinity)
    np.save("test_BindingAffinity.npy", test_BindingAffinity)
    print("Y_train and Y_test Data have been created. :P")
    return [training_set, test_set, refined_set]

[training_set, test_set, refined_set] = listprep("INDEX.2007.refined.data", "PDBbind_core_set_v2007.2.lst")

def create_test(k,v,tau, cut):
    print("Creating Test Set...")
    RIScore_E = [np.zeros([len(tau)*36], float)]
    RIScore_L = [np.zeros([len(tau)*36], float)]

    for i in range(len(test_set)):
        RIfeature_E = np.zeros([len(tau)*36], float)
        RIfeature_L = np.zeros([len(tau)*36], float)
        data = np.load("2007 Complexes/"+list(test_set)[i]+"_complex.npz")
        pro_data, lig_data = data['PRO'], data['LIG']
        for proatm in pro_data:
            for ligatm in lig_data:
                for j in range(len(proatm['typ'])):
                    for x in range(len(ligatm['typ'])):
                        pt = str(proatm['typ'][j]).replace(" ", ""); pt = pt.upper()
                        lt = str(ligatm['typ'][x]).replace(" ", ""); lt = lt.upper()
                        pid = eleid[pt]; lid = eleid[lt]
                        fid = (pid-1)*9+(lid-1)
                        dist = np.linalg.norm(proatm['pos'][j]-ligatm['pos'][x])
                        if dist > cut: continue
                        for l in range(0, len(tau)):
                            eta = (vdw[pt]+vdw[lt])*tau[l]
                            phi_E = math.exp(-(pow((dist/eta),k)))
                            phi_L = 1.0/(1.0+(pow((dist/eta),v)))
                            RIfeature_E[fid+l*36] += phi_E
                            RIfeature_L[fid+l*36] += phi_L
        
        RIScore_E = np.append(RIScore_E, [RIfeature_E], axis = 0)
        RIScore_L = np.append(RIScore_L, [RIfeature_L], axis = 0)

    RIScore_E = RIScore_E[1:]
    RIScore_L = RIScore_L[1:]
    np.save("test_RIScore_E_"+str(k)+str(tau)+str(cut)+".npy", RIScore_E)
    np.save("test_RIScore_L_"+str(v)+str(tau)+str(cut)+".npy", RIScore_L)

def create_train(k,v,tau, cut):
    print("Creating Training Set...")
    RIScore_E = [np.zeros([len(tau)*36], float)]
    RIScore_L = [np.zeros([len(tau)*36], float)]

    for i in range(len(training_set)):
        RIfeature_E = np.zeros([len(tau)*36], float)
        RIfeature_L = np.zeros([len(tau)*36], float)
        data = np.load("2007 Complexes/"+list(training_set)[i]+"_complex.npz")
        pro_data, lig_data = data['PRO'], data['LIG']
        for proatm in pro_data:
            for ligatm in lig_data:
                for j in range(len(proatm['typ'])):
                    for x in range(len(ligatm['typ'])):
                        pt = str(proatm['typ'][j]).replace(" ", ""); pt = pt.upper()
                        lt = str(ligatm['typ'][x]).replace(" ", ""); lt = lt.upper()
                        pid = eleid[pt]; lid = eleid[lt]
                        fid = (pid-1)*9+(lid-1)
                        dist = np.linalg.norm(proatm['pos'][j]-ligatm['pos'][x])
                        if dist > cut: continue
                        for l in range(0, len(tau)):
                            eta = (vdw[pt]+vdw[lt])*tau[l]
                            phi_E = math.exp(-(pow((dist/eta),k)))
                            phi_L = 1.0/(1.0+(pow((dist/eta),v)))
                            RIfeature_E[fid+l*36] += phi_E
                            RIfeature_L[fid+l*36] += phi_L
        
        RIScore_E = np.append(RIScore_E, [RIfeature_E], axis = 0)
        RIScore_L = np.append(RIScore_L, [RIfeature_L], axis = 0)

    RIScore_E = RIScore_E[1:]
    RIScore_L = RIScore_L[1:]

    np.save("train_RIScore_E_"+str(k)+str(tau)+str(cut)+".npy", RIScore_E)
    np.save("train_RIScore_L_"+str(v)+str(tau)+str(cut)+".npy", RIScore_L)

def gbt_rf(k,v,tau,cut):
    X_train_E = np.load("train_RIScore_E_"+str(k)+str(tau)+str(cut)+".npy")
    X_test_E = np.load("test_RIScore_E_"+str(k)+str(tau)+str(cut)+".npy")
    X_train_L = np.load("train_RIScore_L_"+str(v)+str(tau)+str(cut)+".npy")
    X_test_L = np.load("test_RIScore_L_"+str(v)+str(tau)+str(cut)+".npy")
    Y_test = np.load("test_BindingAffinity.npy")
    Y_train = np.load("train_BindingAffinity.npy")

    gbt_e, rf_e, gbt_l, rf_l = [], [], [], []

    #print("Y Training Values...")
    #print(Y_train)
    #print("Y Test Values...")
    #print(Y_test)

    print("Predicting via Exponential Kernel...")
    print("Performing GBT...")
    for i in range(5):
    # GBT
        params={'n_estimators': 20000, 'max_depth': 8, 'min_samples_split': 2,
                'learning_rate': 0.001, 'loss': 'ls','max_features':'sqrt','subsample':0.7}
        clf = ensemble.GradientBoostingRegressor(**params)
        clf.fit(X_train_E, Y_train)
        mse = mean_squared_error(Y_test, clf.predict(X_test_E))
        #print("RMSE: %.4f" % math.sqrt(mse))
        pearcorr = sp.stats.pearsonr(Y_test, clf.predict(X_test_E))
        gbt_e.append(pearcorr[0])

    print("Performing RF...")
    for i in range(5):
    # Random forest
        regr = ensemble.RandomForestRegressor(n_estimators = 1000,max_features='auto')
        regr.fit(X_train_E,Y_train)
        mse = mean_squared_error(Y_test, regr.predict(X_test_E))
        #print("RMSE: %.4f" % math.sqrt(mse))
        pearcorr = sp.stats.pearsonr(Y_test, regr.predict(X_test_E))
        rf_e.append(pearcorr[0])

    print("Predicting via Lorentz Kernel...")
    print("Performing GBT...")
    for i in range(5):
    # GBT
        params={'n_estimators': 20000, 'max_depth': 8, 'min_samples_split': 2,
                'learning_rate': 0.001, 'loss': 'ls','max_features':'sqrt','subsample':0.7}
        clf = ensemble.GradientBoostingRegressor(**params)
        clf.fit(X_train_L, Y_train)
        mse = mean_squared_error(Y_test, clf.predict(X_test_L))
        #print("RMSE: %.4f" % math.sqrt(mse))
        pearcorr = sp.stats.pearsonr(Y_test, clf.predict(X_test_L))
        gbt_l.append(pearcorr[0])

    print("Performing RF...")
    for i in range(5):
    # Random forest
        regr = ensemble.RandomForestRegressor(n_estimators = 1000,max_features='auto')
        regr.fit(X_train_L,Y_train)
        mse = mean_squared_error(Y_test, regr.predict(X_test_L))
        #print("RMSE: %.4f" % math.sqrt(mse))
        pearcorr = sp.stats.pearsonr(Y_test, regr.predict(X_test_L))
        rf_l.append(pearcorr[0])
    
    return [np.median(gbt_e), np.median(rf_e), np.median(gbt_l), np.median(rf_l)]

def create_complex(filename):
    pro_data = np.load("2007 Proteins/PDB/"+filename+"_protein.npz")
    lig_data = np.load("2007 Ligands/MOL/"+filename+"_ligand.npz")

    pro_data = pro_data['PRO']
    lig_data = lig_data['LIG']

    pro_hvy_atom = ['C', 'N', 'O', 'S']
    lig_hvy_atom = ['C', 'N', 'O', 'S', 'P', 'F', 'Cl', 'Br', 'I']

    for pro in pro_data:
        pro_atm = pro['typ']
        pro_coords = pro['pos']

    for lig in lig_data:
        lig_atm = lig['typ']
        lig_coords = lig['pos']
    
    data = dict()
    lig_atm1 = []
    lig_coords1 = []
    for i in range(len(lig_atm)):
        if lig_atm[i].replace(" ", "") in lig_hvy_atom:
            lig_atm1 = np.append(lig_atm1, lig_atm[i])
            if len(lig_coords1)==0:
                lig_coords1 = [lig_coords[i]]
            else:
                lig_coords1 = np.append(lig_coords1, [lig_coords[i]], axis = 0)

    #print(lig_coords)

    pro_atm1 = []
    pro_coords1 = []
    for i in range(len(pro_coords)):
        for k in range(len(lig_coords1)):
            dist = np.linalg.norm(pro_coords[i]-lig_coords1[k])
            #print(pro_coords[i], lig_coords1[k], dist)
            if dist <= 50 and pro_atm[i].replace(" ", "") in pro_hvy_atom:
                pro_atm1 = np.append(pro_atm1, pro_atm[i])
                if len(pro_coords1)==0:
                    pro_coords1 = [pro_coords[i]]
                else:
                    pro_coords1 = np.append(pro_coords1, [pro_coords[i]], axis = 0)
                break

    data['PRO']=[{'typ': pro_atm1, 'pos': pro_coords1}]
    data['LIG']=[{'typ': lig_atm1, 'pos': lig_coords1}]
    np.savez("2007 Complexes/"+filename+"_complex.npz", **data)

def convertpdb(filename):
    f=open(filename, "r")
    if f.mode == 'r':
        contents = f.readlines()
    
    #recordname = []

    #atomNum = []
    #altLoc = []
    #resName = []

    #chainID = []
    #resNum = []
    X = []
    Y = []
    Z = []

    #occupancy = []
    #betaFactor = []
    element = []
    #charge = []
    
    
    for i in range(len(contents)):
        thisLine = contents[i]

        if thisLine[0:4]=='ATOM' and thisLine[17:20] in aa_list:
            #recordname = np.append(recordname,thisLine[:6].strip())
            #atomNum = np.append(atomNum, float(thisLine[6:11]))
            #altLoc = np.append(altLoc,thisLine[16])
            #resName = np.append(resName, thisLine[17:20].strip())
            #chainID = np.append(chainID, thisLine[21])
            #resNum = np.append(resNum, float(thisLine[23:26]))
            X = np.append(X, float(thisLine[30:38]))
            Y = np.append(Y, float(thisLine[38:46]))
            Z = np.append(Z, float(thisLine[46:54]))
            #occupancy = np.append(occupancy, float(thisLine[55:60]))
            #betaFactor = np.append(betaFactor, float(thisLine[61:66]))
            element = np.append(element,thisLine[12:14])

    #print(atomName)
    a = {'PRO': [{'typ': element, 'pos': np.transpose([X,Y,Z])}]}
    np.savez(filename[:-4]+".npz", **a)

def convertmol2(filename):
    f=open(filename, "r")
    if f.mode == 'r':
        contents = f.readlines()
    
    linesize = len(contents)
    
    X = [] 
    Y = []
    Z = []
    atomName = []

    for i in range(linesize):
        if contents[i][0:13] == '@<TRIPOS>ATOM':
            ligstart = i+1
        if contents[i][0:13] == '@<TRIPOS>BOND':
            ligend = i-1
    
    for i in range(ligstart, ligend+1):
        line = contents[i]
        if line[8:17] == 'thiophene':
            typ = line[48:50]
            if not typ[1].isalpha():
                typ = ' '+typ[0]
            x = float(line[18:27])
            y = float(line[27:37])
            z = float(line[37:47])
        else:
            typ = line[47:49]
            if not typ[1].isalpha():
                typ = ' '+typ[0]
            x = float(line[17:26])
            y = float(line[26:36])
            z = float(line[36:46])

        X = np.append(X, x)
        Y = np.append(Y, y)
        Z = np.append(Z, z)
        atomName = np.append(atomName, typ)
    
    data = {'LIG': [{'typ': atomName, 'pos': np.transpose([X,Y,Z])}]}
    np.savez(filename[:-5]+".npz", **data)

def convertall():
    print("Converting Raw Data and Creating Complexes...")
    for i in range(len(refined_set)):
        convertpdb("2007 Proteins/PDB/"+refined_set[i]+"_protein.pdb")
        convertmol2("2007 Ligands/MOL/"+refined_set[i]+"_ligand.mol2")
        create_complex(refined_set[i])

    print("All Complexes Created")



